Character Models 01-06

Each model includes front/back idle, front/back walking, and 8 cleaned back-facing attack frames.
Idle/walking: 240x240 transparent PNG. Attack: 480x300 transparent PNG.
